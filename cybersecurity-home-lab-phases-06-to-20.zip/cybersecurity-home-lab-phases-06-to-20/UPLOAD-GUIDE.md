# GitHub Upload Guide — Phases 6–20

This archive contains one README.md in each phase folder, for Phases 6 through 20.

## Upload through GitHub's website
1. Download and extract this ZIP on your computer.
2. Open your `cybersecurity-home-lab` repository on GitHub.
3. Click **Add file** → **Upload files**.
4. Open the extracted `cybersecurity-home-lab-phases-06-to-20` folder on your computer.
5. Drag the 15 phase folders (Phase-06 through Phase-20) into the GitHub upload area. If dragging folders is not supported in your browser, open each phase folder and upload its `README.md` using **Add file** → **Create new file**, entering the matching path.
6. Review the files before committing. Use a commit message such as `Add documentation for Phases 6–20`.
7. Click **Commit changes**.

## Accuracy note
These READMEs are portfolio-ready drafts based on the lab information available in the conversation. They intentionally do not invent exact scan outputs, packet counts, vulnerabilities, exploits, or domain results that were not recorded. If a phase's activity has not actually been completed, describe it as planned or as a concept reviewed rather than claiming hands-on completion.

## Security note
Before making the repository public, do not upload passwords, API keys, private keys, session tokens, raw packet captures containing sensitive data, or confidential logs.
